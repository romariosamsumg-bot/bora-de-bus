import {mergeVehicles,type Sample} from './history';
export type Vehicle=Sample&{id:string;line:string;speed:number;source:string;age:number;history?:Sample[]};
type Source='conecta'|'zirix';
type State={name:Source;at:number;windowEnd:number;ok:boolean;error?:string;vehicles:Vehicle[];received:number;rejected:number;durationMs:number};
export type Runtime={waitUntil(p:Promise<unknown>):void;store?:{read(name:string):Promise<State|undefined>;write(name:string,value:State):Promise<void>}};
const SOURCES:Source[]=['conecta','zirix'];
const FRESH=180000,REFRESH=25000;
export function validGPS(v:Sample,now:number){const t=Date.parse(v.time);return Number.isFinite(t)&&now-t<=FRESH&&t-now<=60000;}
export class GPSService {
 private states=new Map<Source,State>();private inflight=new Map<Source,Promise<void>>();
 constructor(private fetcher:typeof fetch=fetch,private clock=()=>Date.now(),private firstWaitMs=7000){}
 private async collect(name:Source,runtime?:Runtime){
  const started=this.clock(),old=this.states.get(name);const end=Math.floor(started/10000)*10000;
  // Overlap incremental windows; a cold request gets three minutes of history.
  const begin=old?.ok&&end-old.windowEnd<90000?old.windowEnd-30000:end-FRESH;
  const fmt=(n:number)=>new Date(n).toISOString().replace(/\.\d{3}Z$/,'Z');
  const params=new URLSearchParams({dataInicial:fmt(begin),dataFinal:fmt(end)});
  let state:State;
  try{
   const response=await this.fetcher('https://dados.mobilidade.rio/sppo/'+name+'/gps?'+params,{signal:AbortSignal.timeout(22000)});
   if(!response.ok)throw Error('HTTP '+response.status);
   const body:any=await response.json();const raw=Array.isArray(body)?body:body.data;if(!Array.isArray(raw))throw Error('Formato inesperado');
   const now=this.clock(),tracks=new Map<string,Vehicle[]>();let rejected=0;
   for(const r of raw){const lat=Number(r.latitude),lon=Number(r.longitude),stamp=Date.parse(r.datetime);if(!r.servico||!r.id_veiculo||!Number.isFinite(lat)||!Number.isFinite(lon)||lat< -24||lat> -21||lon< -45||lon> -41)continue;
    if(!Number.isFinite(stamp)||now-stamp>FRESH||stamp-now>60000){rejected++;continue;}
    const v:Vehicle={id:String(r.id_veiculo),line:String(r.servico).trim(),lat,lon,speed:Number(r.velocidade)||0,direction:String(r.sentido||''),shape:String(r.shape_id||''),source:name,time:new Date(stamp).toISOString(),age:Math.max(0,Math.round((now-stamp)/1000))};
    const key=v.line+'|'+v.id;const list=tracks.get(key)||[];list.push(v);tracks.set(key,list);
   }
   const previous=new Map((old?.vehicles||[]).filter(v=>validGPS(v,now)).map(v=>[v.line+'|'+v.id,v]));
   for(const [key,points] of tracks){points.sort((a,b)=>Date.parse(a.time)-Date.parse(b.time));const latest=points[points.length-1],prev=previous.get(key);const newest=prev&&Date.parse(prev.time)>Date.parse(latest.time)?prev:latest;
    const merged=mergeVehicles([{...newest,history:[...(prev?.history||[]),...points]}],[],now)[0];merged.history=merged.history?.filter(p=>now-Date.parse(p.time)<=FRESH);previous.set(key,merged);
   }
   state={name,at:now,windowEnd:end,ok:true,vehicles:[...previous.values()],received:raw.length,rejected,durationMs:now-started};
   if(raw.length>0&&tracks.size===0&&rejected>0){state.ok=false;state.error='Horários do GPS fora da janela de 3 minutos';}
  }catch(e){const now=this.clock();state={name,at:now,windowEnd:old?.windowEnd||end,ok:false,error:e instanceof Error?e.message:'Fonte indisponível',vehicles:(old?.vehicles||[]).filter(v=>validGPS(v,now)),received:0,rejected:0,durationMs:now-started};}
  this.states.set(name,state);
  if(runtime?.store)await runtime.store.write(name,state).catch(()=>{});
 }
 async get(req:Request,runtime?:Runtime){
  const u=new URL(req.url);const lines=[...new Set((u.searchParams.get('lines')||u.searchParams.get('line')||'').split(',').map(s=>s.trim()))];
  if(lines.length>6||lines.some(s=>!s||!/^[\w .-]{1,20}$/.test(s)))return Response.json({error:'Informe de 1 a 6 linhas válidas.'},{status:400,headers:{'Cache-Control':'no-store'}});
  await Promise.all(SOURCES.map(async name=>{if(!this.states.has(name)&&runtime?.store){const saved=await runtime.store.read(name).catch(()=>undefined);if(saved&&this.clock()-saved.at<FRESH&&!this.states.has(name))this.states.set(name,saved);}}));
  const updates:Promise<void>[]=[];
  for(const name of SOURCES){const s=this.states.get(name);if(!s||this.clock()-s.at>=REFRESH){let p=this.inflight.get(name);if(!p){p=this.collect(name,runtime).finally(()=>this.inflight.delete(name));this.inflight.set(name,p);}updates.push(p);runtime?.waitUntil(p);}}
  const hasGPS=()=>[...this.states.values()].some(s=>s.vehicles.some(v=>validGPS(v,this.clock())));
  if(updates.length&&!runtime)await Promise.all(updates);
  else if(updates.length&&!hasGPS()){
   {
    let timer:ReturnType<typeof setTimeout>|undefined;
    const usable=Promise.any(updates.map(p=>p.then(()=>{if(!hasGPS())throw Error('Sem GPS');})) ).catch(()=>{});
    await Promise.race([usable,new Promise<void>(resolve=>{timer=setTimeout(resolve,this.firstWaitMs);})]);if(timer)clearTimeout(timer);
   }
  }
  const now=this.clock(),latest=new Map<string,Vehicle>();
  for(const s of this.states.values())for(const v of s.vehicles){if(!lines.includes(v.line)||!validGPS(v,now))continue;const key=v.line+'|'+v.id,prev=latest.get(key);if(!prev||Date.parse(v.time)>Date.parse(prev.time))latest.set(key,v);}
  const vehicles=[...latest.values()].map(v=>({...v,age:Math.max(0,Math.round((now-Date.parse(v.time))/1000))}));
  const sources=SOURCES.map(name=>{const s=this.states.get(name);return {name,ok:!!s?.ok,count:s?.vehicles.filter(v=>validGPS(v,now)).length||0,checkedAt:s?new Date(s.at).toISOString():null,error:s?.error||null,rejectedTime:s?.rejected||0,durationMs:s?.durationMs||0,updating:this.inflight.has(name)};});
  const updating=this.inflight.size>0,at=Math.max(0,...[...this.states.values()].map(s=>s.at));
  return Response.json({apiVersion:7,vehicles,sources,checkedAt:at?new Date(at).toISOString():null,serverTime:new Date(now).toISOString(),newestGpsAt:vehicles.length?new Date(Math.max(...vehicles.map(v=>Date.parse(v.time)))).toISOString():null,updating,retryAfterSeconds:updating&&!vehicles.length?5:30,freshnessSeconds:180},{headers:{'Cache-Control':'no-store','X-Busao-API':'7'}});
 }
}
