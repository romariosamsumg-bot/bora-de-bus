import {GPSService,type Runtime} from '../../../lib/gps-service';
export const dynamic='force-dynamic';
const gps=new GPSService();
export async function GET(req:Request,runtime?:Runtime){return gps.get(req,runtime);}
