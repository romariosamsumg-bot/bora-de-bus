const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const root=path.resolve(__dirname,'..'),temp=fs.mkdtempSync(path.join(os.tmpdir(),'busao-gps-test-'));
require('node:child_process').execFileSync(path.join(root,'node_modules/.bin/tsc'),['lib/gps-service.ts','lib/history.ts','--outDir',temp,'--module','commonjs','--target','ES2022','--lib','ES2022,DOM','--skipLibCheck'],{cwd:root,stdio:'inherit'});
const {GPSService}=require(path.join(temp,'gps-service.js'));
process.on('exit',()=>fs.rmSync(temp,{recursive:true,force:true}));
(async()=>{
 let now=Date.parse('2026-10-13T20:03:40Z'),calls=0,waiting=[],saved=new Map();
 const raw=(id,line='613',age=10000)=>({id_veiculo:id,servico:line,latitude:-22.95,longitude:-43.35,datetime:new Date(now-age).toISOString(),sentido:'I',shape_id:'fu9d'});
 const request=(q='line=613')=>new Request('https://example.test/api/vehicles?'+q);
 let fail=false;
 const fetcher=async(url)=>{calls++;if(fail)throw Error('offline');return Response.json([raw(url.includes('conecta')?'a':'b'),raw('old','613',10800000),raw('second','692')]);};
 const service=new GPSService(fetcher,()=>now,5);
 let response=await service.get(request()),j=await response.json();assert.equal(j.vehicles.length,2);assert(j.vehicles.every(v=>v.age<=180));assert.equal(calls,2);assert.equal(response.headers.get('Cache-Control'),'no-store');
 j=await(await service.get(request('lines=613,692'))).json();assert.equal(calls,2);assert.equal(j.vehicles.length,3);assert(j.sources.every(s=>s.rejectedTime===1));
 assert.equal((await service.get(request('line=bad!'))).status,400);
 // A source can finish while the other remains blocked; no need to wait for both.
 let resolveSlow;const pending=[];const runtime={waitUntil:p=>pending.push(p),store:{read:async n=>saved.get(n),write:async(n,s)=>{saved.set(n,structuredClone(s));}}};
 const split=new GPSService(async url=>url.includes('conecta')?Response.json([raw('quick')]):new Promise(resolve=>resolveSlow=resolve),()=>now,5);
 j=await(await split.get(request(),runtime)).json();assert.equal(j.vehicles[0].id,'quick');assert(j.updating);assert.equal(j.retryAfterSeconds,30);
 resolveSlow(Response.json([raw('late')]));await Promise.all(pending);j=await(await split.get(request(),runtime)).json();assert.equal(j.vehicles.length,2);assert.equal(j.updating,false);
 // A new isolate reuses edge state without fetching whole-city data again.
 const hydrated=new GPSService(async()=>{throw Error('should not fetch');},()=>now,5);
 j=await(await hydrated.get(request(),runtime)).json();assert.equal(j.vehicles.length,2);
 // All cold calls pending: respond quickly with an explicit retry, not a fake empty success.
 const releases=[],coldPending=[];const cold=new GPSService(()=>new Promise(resolve=>releases.push(resolve)),()=>now,5);
 j=await(await cold.get(request(),{waitUntil:p=>coldPending.push(p)})).json();assert.equal(j.vehicles.length,0);assert(j.updating);assert.equal(j.retryAfterSeconds,5);
 releases.forEach(r=>r(Response.json([raw('ready')])));await Promise.all(coldPending);j=await(await cold.get(request())).json();assert.equal(j.vehicles.length,1);
 // Failed refresh may retain genuinely recent positions; it must not reset GPS timestamps.
 now+=30000;fail=true;j=await(await service.get(request())).json();assert.equal(j.vehicles.length,2);assert(j.sources.every(s=>!s.ok));assert(j.vehicles.every(v=>v.age>=40));
 now+=181000;j=await(await service.get(request())).json();assert.equal(j.vehicles.length,0);
 // A whole feed stamped three hours behind stays rejected, never shifted to 'now'.
 const skew=new GPSService(async()=>Response.json([raw('wrong-clock','613',10800000)]),()=>now,5);
 j=await(await skew.get(request())).json();assert.equal(j.vehicles.length,0);assert(j.sources.every(s=>!s.ok&&s.error.includes('Horários')));
 console.log('GPS: cache, lotes, fonte lenta, resposta parcial, reinício do Worker, retomada, falha e horários antigos passaram.');
})().catch(e=>{console.error(e);process.exit(1)});
