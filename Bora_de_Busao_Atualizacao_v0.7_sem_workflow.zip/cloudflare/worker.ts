import {mobility} from './mobility';
import {GET} from '../app/api/vehicles/route';
export default {
 async fetch(request:Request,env:{ORS_API_KEY?:string;ASSETS:{fetch(request:Request):Promise<Response>}},ctx:{waitUntil(p:Promise<unknown>):void}){
  const u=new URL(request.url);
  if(['/api/address','/api/walk'].includes(u.pathname))return mobility(request,env);
  if(u.pathname==='/api/vehicles'){
   const edge=(caches as unknown as {default:Cache}).default;
   const key=(name:string)=>new Request(u.origin+'/__busao_gps_v7/'+name);
   return GET(request,{waitUntil:p=>ctx.waitUntil(p),store:{
    async read(name){const res=await edge.match(key(name));return res?res.json():undefined},
    async write(name,value){await edge.put(key(name),new Response(JSON.stringify(value),{headers:{'Content-Type':'application/json','Cache-Control':'public, max-age=180'}}))}
   }});
  }
  if(u.pathname.startsWith('/api/'))return Response.json({error:'Não encontrado'},{status:404});
  return env.ASSETS.fetch(request);
 }
};
