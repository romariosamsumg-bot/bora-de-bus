# Atualização GPS 0.7 — Bora de Busao

Esta é uma correção do servidor e da atualização do site. O ZIP não contém workflow, chave ou configuração wrangler.jsonc. Não exige novo serviço pago, chave de API, banco de dados ou troca de domínio.

## O que foi encontrado em 13/10/2026
- A API publicada respondeu em aproximadamente 20 s no teste. A Lite 0.2 usava limite de leitura de 18 s, permitindo que uma resposta válida chegasse depois da desistência do aplicativo.
- O servidor esperava Conecta e Zirix terminarem e baixava cerca de 16 MB de GPS da cidade inteira na consulta fria medida.
- O cache anterior durava 60 s em memória, o navegador ainda podia guardar a resposta por 20 s, e o app/site consultavam a cada 60 s.
- O botão Atualizar do Lite não acionava uma nova consulta quando o serviço de acompanhamento estava ativo.
- Os registros da Conecta estavam cerca de 3 h atrás dos horários UTC declarados pela documentação; a Zirix entregava GPS recente. A correção NÃO soma três horas nem transforma registros antigos em posições atuais.

## O que mudou
Servidor: cache compartilhado no ponto de presença da Cloudflare, por fonte; atualização independente em segundo plano; primeira resposta em até cerca de 7 s de espera interna com indicação de carregamento quando necessário; consulta incremental com sobreposição; múltiplas linhas em uma requisição; resposta sem cache no celular; validação de idade de cada posição. Rede e infraestrutura adicionam sua própria latência — não é garantia de resposta em 7 s totais.
Site: consultas após 30 s da conclusão anterior; retentativa de 5 s enquanto o servidor carrega e 15 s em falha; bloqueio de chamadas simultâneas e limite de espera. Posições recentes podem permanecer durante erro, mas expiram em 3 min.
Lite 0.3: consultas após 30 s da conclusão anterior; chamadas agrupadas (servidor 0.7), botão Atualizar funcional durante acompanhamento, limite de leitura de 35 s, horários com segundos e mensagens que separam GPS de previsão para o ponto. Os pontos projetados no trajeto são reutilizados para reduzir cálculo repetido; a fórmula e os filtros de ETA permanecem iguais. Sessão de até 2 h mantida.

## Publicar pelo celular
1. No GitHub, entre no repositório `romariosamsumg-bot/bora-de-bus`, branch main.
2. Envie `Bora_de_Busao_Atualizacao_v0.7_sem_workflow.zip` na raiz e confirme o commit.
3. Crie `.github/workflows/atualizar-gps-v07.yml` com o texto fornecido separadamente no chat. O ZIP não contém esse workflow.
4. Abra Actions → Atualizar GPS v0.7 → Run workflow → main → Run workflow. Aguarde ficar verde.
5. Na Cloudflare, abra o Worker já existente → Builds. Confirme um novo build com o commit da atualização. Se o build não iniciar, faça um pequeno commit no README.md pela interface do GitHub para disparar a integração. Se houver erro ou aviso de Git desconectado, não crie outro Worker: envie a tela do erro.
6. Mantenha os comandos existentes: build `npm run build`; deploy `npx wrangler deploy --config cloudflare/wrangler.jsonc`.
7. Confira `https://bora-de-bus-rio.romario-samsumg.workers.dev/api/vehicles?line=613`: a resposta deve conter `"apiVersion":7`. O campo `updating:true` pode aparecer enquanto a primeira busca está em andamento; aguarde alguns segundos e consulte de novo.
8. Instale `Bora-de-Busao-Lite-v0.3.apk` por cima do Lite atual. Pare a sessão anterior antes de atualizar; abra o aplicativo e inicie uma nova sessão depois.

O Lite 0.3 também funciona com o servidor anterior: se a consulta em lote não for reconhecida, consulta as linhas separadamente. A melhora completa depende de publicar o servidor 0.7.

## Verificação realizada
Testes determinísticos cobrem cache, chamadas em lote, fonte lenta, carregamento inicial, reuso entre instâncias, falha e horários vencidos. Testes de previsão e avisos do Lite passaram, assim como parsing de lotes e validade temporal. Build web, checagem TypeScript, empacotamento local do Worker (dry-run) e assinatura Android verificados. Integração do novo código com as fontes reais retornou 35 veículos nas linhas 613 e 692 no teste, com a Zirix válida e a Conecta rejeitada por horário. Isso não garante quantidade constante de veículos.
Não houve publicação na conta Cloudflare nem teste em aparelho Android nesta sessão. Não há promessa de precisão ou atualização exata de GPS: fontes e restrições de bateria do Android continuam interferindo.

Para repetir os testes do servidor: `npm install` e `node scripts/gps.test.cjs`.

Referências técnicas:
- https://www.data.rio/documents/2a5d133b3e914065b9ece3790f5e5685
- https://developers.cloudflare.com/workers/runtime-apis/context/
- https://developers.cloudflare.com/workers/reference/how-the-cache-works/
